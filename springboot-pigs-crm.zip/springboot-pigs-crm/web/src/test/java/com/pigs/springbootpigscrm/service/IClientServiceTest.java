package com.pigs.springbootpigscrm.service;


import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * @author PIGS
 * @version 1.0
 * @date 2020/4/4 13:13
 * @effect :
 */
@SpringBootTest
public class IClientServiceTest {

    @Autowired
    private IClientService clientService;


    @Test
    public void queryClientList() {


    }
}