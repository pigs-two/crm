package com.pigs.springbootpigscrm.service;

import com.pigs.springbootpigscrm.entity.EmployeeClientRef;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author PIGS
 * @since 2020-04-03
 */
public interface IEmployeeClientRefService extends IService<EmployeeClientRef> {

}
